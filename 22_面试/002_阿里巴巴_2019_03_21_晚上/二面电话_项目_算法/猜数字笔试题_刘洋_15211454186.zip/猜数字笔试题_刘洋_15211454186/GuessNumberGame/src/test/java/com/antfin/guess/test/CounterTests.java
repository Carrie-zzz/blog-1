package com.antfin.guess.test;

import org.junit.Test;

import com.antfin.guess.bean.EachResult;
import com.antfin.guess.bean.OptimalBean;
import com.antfin.guess.config.ConfigConstant;
import com.antfin.guess.core.Banker;
import com.antfin.guess.core.EntropyCalculator;

/**
 *
 * @版权: Copyright (c) 2019-2020 ****公司技术开发部
 * @author :Steven Liu
 * @E-mail:465282857@qq.com
 * @版本: 1.0
 * @创建日期: 2019年3月24日 下午20:10:30
 * @ClassName CounterTests
 * @类描述-Description: 测试类
 * @修改记录:
 * @版本: 1.0
 */
public class CounterTests {

	@Test
	public void test() {
		ConfigConstant.COUNT_MAX = 10;
		// 次数
		int count = 1000;
		int[] calc = calc(count);
		// 第五次猜中次数
		int sum = 0;
		for (int i = 0; i < ConfigConstant.COUNT_MAX; i++) {
			if (i <= 5) {
				sum += calc[i];
			}
			System.out.println(i + "次,猜中次数" + calc[i]);
		}
		System.out.println(
				count + "次,5次以内猜中次数:" + sum + ",百分比:" + sum * 100.0 / count);
	}

	public int[] calc(int times) {
		EachResult guess = null;
		OptimalBean makeRecommendInput = null;
		// 第一次 猜测数
		int[] start = new int[] { 0, 1, 2, 3 };
		boolean isSuccess = false;
		Banker banker = new Banker();
		banker.init();
		// System.out
		// .println("庄家随机数 :" + Arrays.toString(banker.getRandomNumber()));

		EntropyCalculator entropyCalculator = new EntropyCalculator();
		entropyCalculator.init();

		int[] counters = new int[ConfigConstant.COUNT_MAX];
		for (int i = 0; i < times; i++) {
			while (!banker.isOver()) {
				guess = banker.guess(start);
				// System.out.println("第" + banker.getCount() + "次, 猜测 数"
				// + Arrays.toString(start) + " " + guess);
				if (guess.isSuccess()) {
					isSuccess = true;
					break;
				}
				makeRecommendInput = entropyCalculator.makeRecommendInput(guess,
						start);
				start = makeRecommendInput.getRecommendInput();
			}

			if (isSuccess) {
				// System.out.println("恭喜:" + banker);
				counters[banker.getCount()] += 1;
			} else {
				// System.out.println("很遗憾");
			}

			// reset
			start = new int[] { 0, 1, 2, 3 };
			banker.init();
			entropyCalculator.init();

		}
		return counters;
	}

}
