package com.antfin.guess.bean;

/**
 *
 * @版权: Copyright (c) 2019-2020 ****公司技术开发部
 * @author :Steven Liu
 * @E-mail:465282857@qq.com
 * @版本: 1.0
 * @创建日期: 2019年3月24日 下午3:47:46
 * @ClassName OptimalBean
 * @类描述-Description: 推荐类
 * @修改记录:
 * @版本: 1.0
 */
public class OptimalBean {

	EachResult submitResult;
	/**
	 * 推荐下次输入
	 */
	int[] recommendInput;
	/**
	 * 剩余 可能数目
	 */
	private int lastCount;

	public OptimalBean(EachResult submitResult, int[] recommendInput,
			int lastCount) {
		this.submitResult = submitResult;
		this.recommendInput = recommendInput;
		this.lastCount = lastCount;
	}

	public EachResult getSubmitResult() {
		return submitResult;
	}

	public void setSubmitResult(EachResult submitResult) {
		this.submitResult = submitResult;
	}

	public int[] getRecommendInput() {
		return recommendInput;
	}

	public void setRecommendInput(int[] recommendInput) {
		this.recommendInput = recommendInput;
	}

	public int getLastCount() {
		return lastCount;
	}

	public void setLastCount(int lastCount) {
		this.lastCount = lastCount;
	}

}
