package com.antfin.guess.core;

import java.util.List;

import com.antfin.guess.bean.EachResult;
import com.antfin.guess.bean.OptimalBean;
import com.antfin.guess.config.ConfigConstant;
import com.antfin.guess.util.NumberUtil;

/**
 *
 * @版权: Copyright (c) 2019-2020 ****公司技术开发部
 * @author :Steven Liu
 * @E-mail:465282857@qq.com
 * @版本: 1.0
 * @创建日期: 2019年3月24日 下午1:45:42
 * @ClassName EntropyCalculator
 * @类描述-Description: 核心计算类
 * @修改记录:
 * @版本: 1.0
 */
public class EntropyCalculator {

	private List<int[]> allSubmits;
	private int[] hasErrorState;
	private int[] hasSubmitState;

	public static final int ALL_SUBMIT_NUM = 10 * 9 * 8 * 7;

	public void init() {
		allSubmits = NumberUtil.makeAllData();
		hasSubmitState = new int[allSubmits.size()];
		hasErrorState = new int[allSubmits.size()];
	}

	public void clean() {
		if (allSubmits != null) {
			allSubmits.clear();
		}
		hasSubmitState = null;
		hasErrorState = null;
	}

	public OptimalBean makeRecommendInput(EachResult eachResult, int[] input) {
		// 获取返回，发现不是答案，需要优化信息量
		int[] recommendInput;

		int feadBackValue = eachResult.getFeadBackValue();
		// 删除部分分支
		int lastCount = getItemsToSubmit(feadBackValue, input);
		// 等于0异常
		if (lastCount == 1 || lastCount == 0) {
			recommendInput = getAnswer();
		} else {
			recommendInput = getSubmitInput();
		}

		return new OptimalBean(eachResult, recommendInput, lastCount);

	}

	/**
	 * 计算当前剩余item可提交数量
	 * 
	 * @param feedback
	 * @param currentSubmit
	 * @return
	 */
	public int getItemsToSubmit(int feedback, int[] currentSubmit) {
		int sum = 0;
		for (int i = 0; i < ALL_SUBMIT_NUM; i++) {
			if (hasErrorState[i] == 1) {
				continue;
			} else if (NumberUtil
					.calResultForEachSubmit(allSubmits.get(i), currentSubmit)
					.getFeadBackValue() != feedback) {
				hasErrorState[i] = 1;
			} else {
				sum++;
			}
		}
		return sum;
	}

	/**
	 * 当且仅当 getItemsToSubmit 返回1的时候是对的
	 * 
	 * @return
	 */
	public int[] getAnswer() {
		for (int i = 0; i < ALL_SUBMIT_NUM; i++) {
			if (hasErrorState[i] == 1)
				continue;
			return allSubmits.get(i);
		}
		return null;
	}

	public int[] getSubmitInput() {
		double maxEntropy = 0;
		int[] feedBacks;
		int[] recommendSubmit = null;

		for (int i = 0; i < ALL_SUBMIT_NUM; i++) {
			// 剔除已经并不可能的选项
			if (hasSubmitState[i] == 1 || hasErrorState[i] == 1) {
				continue;
			}

			feedBacks = makeFeedBacks();
			getAllFeedBacks(feedBacks, allSubmits.get(i));

			double entropy = calEntropy(feedBacks);

			if (entropy < 0.00001) {
				hasSubmitState[i] = 1;
				continue;
			}

			// 寻找最大信息量
			if (maxEntropy < entropy) {
				maxEntropy = entropy;
				recommendSubmit = allSubmits.get(i);
			}
		}
		return recommendSubmit;
	}

	/**
	 * 获取空反馈集
	 * 
	 * @return
	 */
	public int[] makeFeedBacks() {
		return new int[(ConfigConstant.NUMBER_LENGTH + 1)
				* (ConfigConstant.NUMBER_LENGTH + 1)];
	}

	/**
	 * 计算当前提交与所有答案的反馈，并记录反馈列表
	 * 
	 * @param feedBacks
	 *            反馈集合
	 * @param submit
	 *            当前提交
	 */
	public void getAllFeedBacks(int[] feedBacks, int[] submit) {
		for (int i = 0; i < ALL_SUBMIT_NUM; i++) {
			if (hasErrorState[i] != 0) {
				continue;
			}
			EachResult calResultForEachSubmit = NumberUtil
					.calResultForEachSubmit(submit, allSubmits.get(i));
			feedBacks[calResultForEachSubmit.getFeadBackValue()]++;
		}
	}

	/**
	 * 计算根据反馈计算信息量
	 * 
	 * @return
	 */
	public static double calEntropy(int[] feedBacks) {
		int sum = 0;
		double entropy = 0.;
		for (int i = 0; i < feedBacks.length; i++) {
			sum += feedBacks[i];
		}
		for (int j = 0; j < feedBacks.length; j++) {
			// 跳过 0A0B 场景
			if (feedBacks[j] == 0) {
				continue;
			}
			// 计算比重
			float tmp = (float) feedBacks[j] / sum;
			entropy += -1 * tmp * Math.log(tmp);
		}
		return entropy;
	}
}
