package com.antfin.guess.bean;

/**
 *
 * @版权: Copyright (c) 2019-2020 ****公司技术开发部
 * @author :Steven Liu
 * @E-mail:465282857@qq.com
 * @版本: 1.0
 * @创建日期: 2019年3月24日 下午2:03:42
 * @ClassName EachResult
 * @类描述-Description: 每次提交封装类
 * @修改记录:
 * @版本: 1.0
 */
public class EachResult {

	private int[] submit;

	private int a;

	private int b;

	public EachResult(int a, int b) {
		this(a, b, null);
	}

	public EachResult(int a, int b, int[] submit) {
		this.submit = submit;
		this.a = a;
		this.b = b;
	}

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

	public int[] getSubmit() {
		return submit;
	}

	public void setSubmit(int[] submit) {
		this.submit = submit;
	}

	/**
	 * 计算每一次得到的反馈，定义xAyB为 x*5+b为反馈 20位正确答案
	 * 
	 * @return
	 */
	public int getFeadBackValue() {
		return a * 5 + b;
	}

	public boolean isSuccess() {
		return a == 4;
	}

	@Override
	public String toString() {
		return a + "A" + b + "B";
	}

}
