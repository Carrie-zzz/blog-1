package com.antfin.guess.config;

/**
 *
 * @版权: Copyright (c) 2019-2020 ****公司技术开发部
 * @author :Steven Liu
 * @E-mail:465282857@qq.com
 * @版本: 1.0
 * @创建日期: 2019年3月24日 下午4:16:03
 * @ClassName ConfigConstant
 * @类描述-Description: 配置类
 * @修改记录:
 * @版本: 1.0
 */
public class ConfigConstant {
	/**
	 * 随机数 长度
	 */
	public final static int NUMBER_LENGTH = 4;
	/**
	 * 最大猜测次数
	 */
	public static int COUNT_MAX = 5;

}
