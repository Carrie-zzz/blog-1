package com.antfin.guess.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.antfin.guess.bean.EachResult;

/**
 *
 * @版权: Copyright (c) 2019-2020 ****公司技术开发部
 * @author :Steven Liu
 * @E-mail:465282857@qq.com
 * @版本: 1.0
 * @创建日期: 2019年3月23日 下午11:04:17
 * @ClassName NumberUtil
 * @类描述-Description: 数子工具类
 * @修改记录:
 * @版本: 1.0
 */
public class NumberUtil {

	/**
	 * 生成 n位随机数字（每位数字各不相同）
	 * 
	 * @return
	 */
	public static int[] genRandomNumber(int n) {
		Random random = new Random();
		int[] arr = new int[n];
		arr[0] = random.nextInt(9);
		int i = 1;
		while (i <= n - 1) {
			int x = random.nextInt(9);
			for (int j = 0; j <= i - 1; j++) {
				if (arr[j] == x) {
					break;
				} else if (j + 1 == i) {
					arr[i] = x;
					i++;
				}
			}
		}
		return arr;
	}

	/**
	 * string 转 int 数组
	 * 
	 * @param string
	 * @return
	 */
	public static int[] parseString2IntArray(String string) {
		int[] result = null;
		if (string == null) {
			return result;
		}
		int length = string.length();
		result = new int[length];
		for (int i = 0; i < length; i++) {
			try {
				Character ch = string.charAt(i);
				result[i] = Integer.parseInt(ch.toString());
			} catch (Exception e) {
				return null;
			}
		}
		return result;
	}

	/**
	 * 创建所有的数据
	 *
	 * @return
	 */
	public static List<int[]> makeAllData() {
		List<int[]> allData = new ArrayList<int[]>();
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				for (int k = 0; k < 10; k++) {
					for (int l = 0; l < 10; l++) {
						if (i != j && i != k && i != l && j != k && j != l
								&& k != l) {
							int[] item = new int[] { i, j, k, l };
							allData.add(item);
						}
					}
				}
			}
		}
		return allData;
	}

	/**
	 * 计算 几A几B
	 * 
	 * @param submit
	 * @param result
	 * @return
	 */
	public static EachResult calResultForEachSubmit(int[] submit,
			int[] result) {
		// 检测A
		int a = checkA(submit, result);
		// 检测B
		int b = checkB(submit, result);

		return new EachResult(a, b, submit);
	}

	/**
	 * A代表数字和位置都相同
	 * 
	 * @param submit
	 *            输入参数
	 * @param result
	 *            输出参数
	 * @return
	 */
	public static int checkA(int[] submit, int[] result) {
		int counter = 0;
		for (int i = 0; i < submit.length; i++) {
			if (submit[i] == result[i]) {
				counter++;
			}
		}
		return counter;
	}

	/**
	 * B代表包含该数字但位置不同
	 * 
	 * @param num
	 * @param position
	 * @return
	 */
	public static int checkB(int[] submit, int[] result) {
		int counter = 0;
		for (int i = 0; i < submit.length; i++) {
			for (int j = 0; j < result.length; j++) {
				if (submit[i] == result[j] && i != j) {
					counter++;
				}
			}
		}
		return counter;
	}
}