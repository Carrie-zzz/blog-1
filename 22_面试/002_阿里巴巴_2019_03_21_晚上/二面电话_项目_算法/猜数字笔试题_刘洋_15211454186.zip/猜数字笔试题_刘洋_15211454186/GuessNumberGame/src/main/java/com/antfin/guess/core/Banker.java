package com.antfin.guess.core;

import java.util.Arrays;

import com.antfin.guess.bean.EachResult;
import com.antfin.guess.config.ConfigConstant;
import com.antfin.guess.util.NumberUtil;

/**
 *
 * @版权: Copyright (c) 2019-2020 ****公司技术开发部
 * @author :Steven Liu
 * @E-mail:465282857@qq.com
 * @版本: 1.0
 * @创建日期: 2019年3月23日 下午6:32:10
 * @ClassName Banker
 * @类描述-Description: 庄家
 * @修改记录:
 * @版本: 1.0
 */
public class Banker {
	/**
	 * 随机答案
	 */
	private int[] randomNumber;
	/**
	 * 猜测次数
	 */
	private int count;
	/**
	 * 游戏是否结束
	 */
	private boolean isOver = true;

	public void init() {
		this.randomNumber = NumberUtil
				.genRandomNumber(ConfigConstant.NUMBER_LENGTH);
		this.count = 0;
		this.isOver = false;
	}

	public EachResult guess(int num) {
		return guess(NumberUtil.parseString2IntArray(String.valueOf(num)));
	}

	public EachResult guess(int[] submit) {
		// 检验 状态 和 参数
		if (isOver) {
			return new EachResult(0, 0);
		}
		if (submit == null || submit.length != ConfigConstant.NUMBER_LENGTH) {
			return new EachResult(0, 0);
		}
		// 计数器
		count++;
		checkOver();
		EachResult calResultForEachSubmit = NumberUtil
				.calResultForEachSubmit(submit, randomNumber);
		if (calResultForEachSubmit.isSuccess()) {
			isOver = true;
		}
		return calResultForEachSubmit;
	}

	/**
	 * 是否结束
	 * 
	 * @param num
	 * @return
	 */
	public void checkOver() {
		if (ConfigConstant.COUNT_MAX <= count) {
			isOver = true;
		}
	}

	public boolean isOver() {
		return isOver;
	}

	public int[] getRandomNumber() {
		return randomNumber;
	}

	public int getCount() {
		return count;
	}

	@Override
	public String toString() {
		return "计算次数:" + count + " 答案 :" + Arrays.toString(randomNumber);
	}

}
