package com.antfin.guess;

import java.util.Arrays;

import com.antfin.guess.bean.EachResult;
import com.antfin.guess.bean.OptimalBean;
import com.antfin.guess.core.Banker;
import com.antfin.guess.core.EntropyCalculator;

/**
 *
 * @版权: Copyright (c) 2019-2020 ****公司技术开发部
 * @author :Steven Liu
 * @E-mail:465282857@qq.com
 * @版本: 1.0
 * @创建日期: 2019年3月23日 下午6:30:30
 * @ClassName GuessNumberMain
 * @类描述-Description: 主函数
 * 
 * @修改记录:
 * 
 * @版本: 1.0
 * 
 * @题目类容
 * 
 * 		有一个猜数字游戏，庄家预先写下一个四位数字（每位数字各不相同），玩家每次随机猜一个数字，庄家告知玩家猜对了几A几B（A代表数字和位置都相同，B代表包含该数字但位置不同，比如如果庄家写的是3514，玩家猜的是3165，庄家会回答1A2B），玩家继续猜，直到猜中为止。如果超过5轮没猜中，则玩家输，否则玩家赢。请为玩家设计一个猜数字的算法，确保玩家能够大概率胜。
 *       例如：庄家写下9876，玩家第一次猜0123，庄家回复0A0B；玩家继续猜4567，庄家回复0A2B；依次下去，直到玩家猜中9876为止。
 *       提示：可以用排除法，根据庄家的反馈排除部分数字。
 * 
 */
public class GuessNumberMain {

	public static void main(String[] args) {
		EachResult guess = null;
		OptimalBean makeRecommendInput = null;
		// 第一次 猜测数
		int[] start = new int[] { 0, 1, 2, 3 };
		boolean isSuccess = false;

		Banker banker = new Banker();
		banker.init();
		System.out
				.println("庄家随机数 :" + Arrays.toString(banker.getRandomNumber()));

		EntropyCalculator entropyCalculator = new EntropyCalculator();
		entropyCalculator.init();
		while (!banker.isOver()) {
			guess = banker.guess(start);
			System.out.print("第" + banker.getCount() + "次, 猜测 数"
					+ Arrays.toString(start) + " " + guess);
			if (guess.isSuccess()) {
				isSuccess = true;
				break;
			}
			makeRecommendInput = entropyCalculator.makeRecommendInput(guess,
					start);
			System.out.println(" 剩余可能数目" + makeRecommendInput.getLastCount());
			start = makeRecommendInput.getRecommendInput();
		}
		System.out.println();
		if (isSuccess) {
			System.out.println("恭喜:" + banker);
		} else {
			System.out.println("很遗憾");
		}
	}

}
